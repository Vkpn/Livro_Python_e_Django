def limpa_tela():
    print('\n' * 100)
