from setuptools import setup

setup(
    name='controlafila',
    version='1.0',
    description='controle de fila',
    author='Victor',
    author_email='teste@teste.com.br',
    url='teste.com.br',
    py_modules=['atender', 'incluir', 'limpatela', 'menu', 'verificafila'],
)
